# Midori128-64

## Setup:
1. Clone the repo, or download all the files.
2. Open terminal and run **python3 main.py**
3. Enter message to be encrypted.

The Key is generated at random. The main uses 128-bit version for the demo.

# UDP Client-Server Midori-64 encryption based messaging
1. Open two terminal: T_client and T_server
2. In T_server execute /App/server.py.
3. In T_client execute /App/client.py.
4. Enter message to be sent in client.
*Note: Server is hosted at localport:8080 if you want to change to change **localport** parameter in server.py and **server_address** in client.py.*
   
