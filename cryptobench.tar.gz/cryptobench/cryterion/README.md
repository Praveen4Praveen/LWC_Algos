## References
- <https://docs.python.org/3/library/gc.html>
